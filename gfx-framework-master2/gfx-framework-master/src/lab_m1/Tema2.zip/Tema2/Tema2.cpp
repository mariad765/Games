#include "lab_m1/Tema2/Tema2.h"
#include "ParticleSystem.h"
#include <vector>
#include <string>
#include <iostream>
#include <cmath>

using namespace std;
using namespace m1;

#include "lab_m1/lab4/transform3D.h"

/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


 /////////////////////////////////////////////////////////////////VARIABLES///////////////////////////////////////////////
float rotationAngleElice = 0.0f; // Angle of rotation, initially 0
float rotationAngleDrona = 0.0f;
float translateX = 0.0f;
float translateY = 0.0f;
float translateZ = 0.0f;
int nrHouses = 20;
int nrTrees = 30;
int nrCheckpoints = 10;
float oldCameraX = 0.0f;
float oldCameraY = 0.0f;
float oldCameraZ = 0.0f;
float  foliageBaseRadius = 1.5f;
float foliageHeight = 2.0f;
float trunkRadius = 0.2f;
float trunkHeight = 3.0f;
// Dimensions for the drone
float width1 = 0.6f;   // Width of the first part of the drone
float height = 0.04f;  // Height of the drone (same for both parts)
float depth1 = 0.04f;  // Depth of the first part of the drone
float width2 = 0.04f;  // Width of the second part of the drone
float depth2 = 0.6f;   // Depth of the second part of the drone
int currentCheckpoint = 0;
glm::mat4 oldModelMatrix;
glm::mat4 droneModelMatrix;
glm::mat4 arrowMatrix = glm::mat4(1.0f);
glm::mat4 oldArrowMatrix = glm::mat4(1.0f);
std::vector<glm::mat4> propellerModelMatrices(4, glm::mat4(1.0f));
std::vector<glm::mat4> oldPropellerModelMatrices(4, glm::mat4(1.0f));
std::vector<glm::vec3> housePositions;
std::vector<glm::vec3> treePositions;
std::vector<glm::vec3> nextCheckpoints;
std::vector<glm::vec3> checkpointsYellowGreen;
//checkpoint stuff
enum CheckpointState {
    NOT_ENTERED,
    ENTERED_GREEN,
    COMPLETED,
    DEACTIVATED
};
std::vector<CheckpointState> checkpointStates(nrCheckpoints, DEACTIVATED);

struct AABB {
    glm::vec3 min;  // Min corner (x, y, z)
    glm::vec3 max;  // Max corner (x, y, z)
};
std::vector<AABB> houseAABBs;
std::vector<std::pair<AABB, AABB>> treeAABBs;
AABB droneAABB;
std::vector<std::tuple<AABB, AABB, AABB>> checkpointAABB;
std::vector<std::tuple<AABB, AABB, AABB>> checkpointNextAABB;


// Propellers
glm::vec3 propellerOffsets[] = {
    glm::vec3(0.4f, 0.05f, 0.4f),   // Front-right
    glm::vec3(-0.4f, 0.05f, 0.4f),  // Front-left
    glm::vec3(-0.4f, 0.05f, -0.4f), // Rear-left
    glm::vec3(0.4f, 0.05f, -0.4f)   // Rear-right
};





/////////////////////////////////////////////////////////////////FUNCTIONS///////////////////////////////////////////////
// Utility function to rotate a vector around the Y-axis
glm::vec3 RotateAroundYAxis(const glm::vec3& position, float angleRadians) {
    float cosTheta = cos(angleRadians);
    float sinTheta = sin(angleRadians);
    return glm::vec3(
        position.x * cosTheta - position.z * sinTheta,
        position.y,
        position.x * sinTheta + position.z * cosTheta
    );
}


float fade(float t) {
    return t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f);
}

float grad(int hash, glm::vec2 p) {
    int h = hash & 3;
    float u = (h < 2) ? p.x : p.y;
    float v = (h < 2) ? p.y : p.x;
    return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
}

float perlinNoise(glm::vec2 st) {
    glm::vec2 i = glm::floor(st);
    glm::vec2 f = glm::fract(st);

    int h00 = static_cast<int>(std::fmod(glm::dot(i, glm::vec2(127.1f, 311.7f)), 256.0f));
    int h10 = static_cast<int>(std::fmod(glm::dot(i + glm::vec2(1.0f, 0.0f), glm::vec2(127.1f, 311.7f)), 256.0f));
    int h01 = static_cast<int>(std::fmod(glm::dot(i + glm::vec2(0.0f, 1.0f), glm::vec2(127.1f, 311.7f)), 256.0f));
    int h11 = static_cast<int>(std::fmod(glm::dot(i + glm::vec2(1.0f, 1.0f), glm::vec2(127.1f, 311.7f)), 256.0f));

    float g00 = grad(h00, f);
    float g10 = grad(h10, f - glm::vec2(1.0f, 0.0f));
    float g01 = grad(h01, f - glm::vec2(0.0f, 1.0f));
    float g11 = grad(h11, f - glm::vec2(1.0f, 1.0f));

    glm::vec2 fadeXY = glm::vec2(fade(f.x), fade(f.y));

    float n0 = glm::mix(g00, g10, fadeXY.x);
    float n1 = glm::mix(g01, g11, fadeXY.x);
    return glm::mix(n0, n1, fadeXY.y);
}

float fractalNoise(glm::vec2 st, int octaves, float persistence) {
    float total = 0.0f;
    float amplitude = 1.0f;
    float frequency = 1.0f;
    float maxValue = 0.0f;

    for (int i = 0; i < octaves; i++) {
        total += perlinNoise(st * frequency) * amplitude;
        maxValue += amplitude;
        amplitude *= persistence;
        frequency *= 2.0f;
    }

    return total / maxValue;
}

float enhanceWithLakes(float height) {
    float lakeThreshold = -0.15f;
    float lakeDepth = -0.3f;
    float smoothness = 0.05f;

    float transition = glm::smoothstep(lakeThreshold - smoothness, lakeThreshold + smoothness, height);

    if (height < lakeThreshold) {
        return glm::mix(lakeDepth, height, transition);
    }

    return height;
}

float GetTerrainHeight(float x, float z) {
    float frequency = 0.26f;
    int octaves = 7;
    float persistence = 0.5f;

    float height = fractalNoise(glm::vec2(x, z) * frequency, octaves, persistence);
    height = enhanceWithLakes(height);

    float terrainOffset = 0.2f;

    return height + terrainOffset; // z of terrain max
}

bool IsPositionTooClose(glm::vec3 newPosition, float minDistance) {
    for (const glm::vec3& pos : housePositions) {
        // Calculate distance between new position and existing position
        float distance = glm::length(newPosition - pos);
        if (distance < minDistance) {
            return true;  // Too close to another object
        }
    }
	for (const glm::vec3& pos : treePositions) {
		// Calculate distance between new position and existing position
		float distance = glm::length(newPosition - pos);
		if (distance < minDistance) {
			return true;  // Too close to another object
		}
	}
    return false;  // No objects within the radius
}
// Function to generate a random float in a range
glm::vec3 RandomObjectPosition(float minX, float maxX, float minY, float maxY) {
    // generate random x and random y within the specified range
    float randomX = (rand() / (float)RAND_MAX) * (maxX - minX) + minX;
    float randomY = (rand() / (float)RAND_MAX) * (maxY - minY) + minY;

    // Get terrain height at the random position
    float terrainHeight = GetTerrainHeight(randomX, randomY);

    // print position vector
    cout << "Random position: " << randomX << " " << terrainHeight << " " << randomY << endl;

    glm::vec3 newPos (randomX, terrainHeight, randomY);

    // Check if the terrain height is valid, if not, generate new position
    if (terrainHeight > 0.0f && !IsPositionTooClose(newPos,3))
        return glm::vec3(randomX, terrainHeight, randomY);
    else
        return RandomObjectPosition(minX, maxX, minY, maxY);  // Recurse if terrain height is too low
}


bool CheckGroundCollision(glm::vec3 dronePosition) {

        // Check multiple points along the perimeter of the circle with radius
        int numPoints = 100; // Number of points to check (you can increase this for more precision)
        float radius = 0.5;
        // Loop through each point on the perimeter
        for (int i = 0; i < numPoints; ++i) {
            // Calculate the angle for each point along the circle's perimeter
            float angle = i * 2.0f * glm::pi<float>() / numPoints;

            // Calculate the position of each point on the perimeter
            glm::vec3 checkPosition = glm::vec3(
                dronePosition.x + radius * cos(angle),
                dronePosition.y ,  // We keep the drone's y position as is for height checking
                dronePosition.z + radius * sin(angle)
            );

            // Get the terrain height at this position
            float terrainHeight = GetTerrainHeight(checkPosition.x, checkPosition.z);

            // If the drone is below the terrain (considering tolerance), there is a collision
            if (checkPosition.y  <= terrainHeight) {
                return true;  // Collision with ground
            }
        }

        // No collision detected with the ground for any of the points
        return false;
}

bool CheckAABBCollision(const AABB& a, const AABB& b) {
    // Check if there is no overlap along any axis
    if (a.max.x < b.min.x || a.min.x > b.max.x) return false; // X-axis overlap
    if (a.max.y < b.min.y || a.min.y > b.max.y) return false; // Y-axis overlap
    if (a.max.z < b.min.z || a.min.z > b.max.z) return false; // Z-axis overlap

    // If no condition above is true, the AABBs are colliding
    return true;
}


bool CheckCollisionWithObstacles(const glm::vec3& playerPosition) {
    // Create an AABB for the player's bounding box (based on the player's size and position)
    glm::vec3 playerMin = playerPosition - glm::vec3(0.5f, 0.0f, 0.5f); // Example player AABB size
    glm::vec3 playerMax = playerPosition + glm::vec3(0.5f, 1.8f, 0.5f); // Example player AABB size

    AABB playerAABB{ playerMin, playerMax };

    // Iterate over the treeAABBs vector (which contains pairs of AABBs for trunk and cone)
    for (const auto& treePair : treeAABBs) {
        // Check for collision between player and both the trunk and cone AABBs
        if (CheckAABBCollision(playerAABB, treePair.first) || CheckAABBCollision(playerAABB, treePair.second)) {
            return true; // Collision detected
        }
    }

	// Iterate over the houseAABBs vector
	for (const auto& houseAABB : houseAABBs) {
		// Check for collision between player and house AABB
		if (CheckAABBCollision(playerAABB, houseAABB)) {
			return true; // Collision detected
		}
	}

    for (int i = 0; i < checkpointAABB.size(); i++) {
        // Check for collision between player and both the stick and circle AABBs
        if (CheckAABBCollision(playerAABB, std::get<0>(checkpointAABB[i]))) {
            return true; // Collision detected
        }

        if (checkpointStates[i] == DEACTIVATED) {
            // Check if the drone collides with the yellow circle
            if (CheckAABBCollision(playerAABB, std::get<2>((checkpointAABB[i])))) {
                return true;
            }
        }

        if ((checkpointStates[i]) == NOT_ENTERED) {

            if (CheckAABBCollision(playerAABB, std::get<2>(checkpointAABB[i]))) {
                printf("intra galben not_entered");

                return true;
            }
        }
        if (checkpointStates[i] == NOT_ENTERED) {
            // Check if the drone collides with the green circle
            if (CheckAABBCollision(playerAABB, std::get<1>((checkpointAABB[i])))) {
                checkpointStates[i] = ENTERED_GREEN;
				checkpointStates[i] = COMPLETED;
				currentCheckpoint++;
            }
        }
      
    }
	for (const auto& checkpointPair : checkpointNextAABB) {
		// Check for collision between player and both the stick and circle AABBs
		if (CheckAABBCollision(playerAABB, std::get<0>(checkpointPair))) {
			return true; // Collision detected
		}
	}
    // No collision detected with any obstacles
    return false;
}






Tema2::Tema2()
{
}


Tema2::~Tema2()
{
}


void Tema2::Init()
{
    renderCameraTarget = false;
    orthoProjection = false;
    projectionFov = 60.0f;
    projectionWidth = 16.0f;
    projectionHeight = 9.0f;

    glm::vec3 minPoint = glm::vec3(-std::max(width1, width2), -height, -std::max(depth1, depth2));  // The minimum point of the AABB
    glm::vec3 maxPoint = glm::vec3(std::max(width1, width2), height, std::max(depth1, depth2));     // The maximum point of the AABB

    // Create the AABB for the drone
	droneAABB = AABB{ minPoint, maxPoint };


	for (int i = 0; i < nrHouses; i++)
	{
        glm::vec3 position = RandomObjectPosition(-50, 130, -50, 130);
        housePositions.push_back(position);

        // Define AABB for the house (adjusted size based on suggested dimensions)
        glm::vec3 minPoint = position - glm::vec3(1.0f, 0.0f, 1.0f); // Half the width and depth
        glm::vec3 maxPoint = position + glm::vec3(1.0f, 6.0f, 1.0f); // Half the width and depth, plus full height

        houseAABBs.push_back(AABB{ minPoint, maxPoint });
	}
    for (int i = 0; i < nrTrees; i++) {
		
        glm::vec3 position = RandomObjectPosition(-50, 130, -50, 130);
        treePositions.push_back(position);

        // Define AABB for the tree (adjust size for both the cylinder trunk and cone top)
        glm::vec3 trunkMin = position - glm::vec3(trunkRadius, 0.0f, trunkRadius);
        glm::vec3 trunkMax = position + glm::vec3(trunkRadius, trunkHeight + 3.0f, trunkRadius);


        glm::vec3 coneMin = position - glm::vec3(foliageBaseRadius, 0.0f, foliageBaseRadius);
        coneMin.y += trunkHeight + 1.8f; // Adjust Y-coordinate to start at trunkHeight
        glm::vec3 coneMax = position + glm::vec3(foliageBaseRadius, foliageHeight-0.5f, foliageBaseRadius);
        coneMax.y += trunkHeight; // Adjust Y-coordinate to include foliage height

        // Store AABBs for the trunk and cone as a pair
        treeAABBs.push_back(std::make_pair(AABB{ trunkMin, trunkMax }, AABB{ coneMin, coneMax }));
    }

    for (int i = 0; i < nrCheckpoints; i++)
    {
        glm::vec3 position = RandomObjectPosition(-50, 130, -50, 130);
        nextCheckpoints.push_back(position);
        checkpointsYellowGreen.push_back(position);

        // Define dimensions for the stick
        float stickLength = 1.5f;   // Length of the stick
        float stickThickness = 0.1f; // Thickness of the stick


        // Define dimensions for the circle
        float circleRadius = 1.0f;  // Radius of the circle
        float circleThickness = 0.3f; // Depth of the circle

        // Calculate AABB for the stick
        glm::vec3 stickMin = position - glm::vec3(stickThickness,0.0f, stickThickness);
        glm::vec3 stickMax = position + glm::vec3(stickThickness, stickLength, stickThickness);

        // Calculate AABB for the green side of the circle
        glm::vec3 greenCircleCenter = position; // Circle is at the top of the stick
        glm::vec3 greenCircleMin = greenCircleCenter - glm::vec3(circleRadius, stickLength, circleThickness);
       // greenCircleMin.y -= circleThickness / 2.0f; // Adjust for circle depth
        glm::vec3 greenCircleMax = greenCircleCenter + glm::vec3(circleRadius, 2*circleRadius+ stickLength, circleThickness);
        //greenCircleMax.y -= circleThickness / 2.0f; // Adjust for circle depth

        // Assuming the position of the yellow circle and its dimensions are defined:
        glm::vec3 yellowCircleCenter = position; // Center of the yellow circle (same as green circle)

        // Calculate the yellow circle AABB
        glm::vec3 yellowCircleMin = yellowCircleCenter - glm::vec3(circleRadius, stickLength, circleThickness);
        yellowCircleMin.z -= 2*circleThickness / 2.0f; // Adjust for circle depth

        glm::vec3 yellowCircleMax = yellowCircleCenter + glm::vec3(circleRadius, circleRadius*2+ stickLength, circleThickness);
        yellowCircleMax.z -= 2*circleThickness / 2.0f; // Adjust for circle depth


        
        // Store as a tuple of AABBs (stick, green circle, yellow circle)
        checkpointAABB.push_back(std::make_tuple(AABB{ stickMin, stickMax }, AABB{ greenCircleMin, greenCircleMax }, AABB{ yellowCircleMin, yellowCircleMax }));
        checkpointNextAABB.push_back(std::make_tuple(AABB{ stickMin, stickMax }, AABB{ greenCircleMin, greenCircleMax }, AABB{ yellowCircleMin, yellowCircleMax }));
    }


    camera = new implemented::Camera1();
    camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

    // Corp Drona
    {
        float x = 0.6f;
        float y = 0.04f;
        float z = 0.04f;

        float x2 = 0.04f;
        float z2 = 0.6f;

        glm::vec3 colorDrona = glm::vec3(0, 0, 1);
        vector<VertexFormat> vertices
        {
            // Prima parte
            VertexFormat(glm::vec3(-x, -y,  z), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 0
            VertexFormat(glm::vec3(x, -y,  z),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 1
            VertexFormat(glm::vec3(-x,  y,  z), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 2
            VertexFormat(glm::vec3(x,  y,  z),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 3
            VertexFormat(glm::vec3(-x, -y, -z), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 4
            VertexFormat(glm::vec3(x, -y, -z),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 5
            VertexFormat(glm::vec3(-x,  y, -z), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 6
            VertexFormat(glm::vec3(x,  y, -z),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 7

            // A doua parte
            VertexFormat(glm::vec3(-x2, -y,  z2), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 8
            VertexFormat(glm::vec3(x2, -y,  z2),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 9
            VertexFormat(glm::vec3(-x2,  y,  z2), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 10
            VertexFormat(glm::vec3(x2,  y,  z2),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 11
            VertexFormat(glm::vec3(-x2, -y, -z2), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 12
            VertexFormat(glm::vec3(x2, -y, -z2),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 13
            VertexFormat(glm::vec3(-x2,  y, -z2), colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 14
            VertexFormat(glm::vec3(x2,  y, -z2),  colorDrona, glm::vec3(0.2, 0.8, 0.6)), // 15
        };

        vector<unsigned int> indices =
        {
            // Indices for prima parte
            0, 1, 2,
            1, 3, 2,
            2, 3, 7,
            2, 7, 6,
            1, 7, 3,
            1, 5, 7,
            6, 7, 4,
            7, 5, 4,
            0, 4, 1,
            1, 4, 5,
            2, 6, 4,
            0, 2, 4,

            // Indices for a doua parte
            8, 9, 10,
            9, 11, 10,
            10, 11, 15,
            10, 15, 14,
            9, 15, 11,
            9, 13, 15,
            14, 15, 12,
            15, 13, 12,
            8, 12, 9,
            9, 12, 13,
            10, 14, 12,
            8, 10, 12,
        };

        meshes["Drona"] = new Mesh("generated cube 1");
        meshes["Drona"]->InitFromData(vertices, indices);
    }

    // Elice
    {
        float x = 0.14f;
        float y = 0.001f;
        float z = 0.01f;
        glm::vec3 colorElice = glm::vec3(1, 0, 0);
        vector<VertexFormat> vertices
        {
            VertexFormat(glm::vec3(x, y, z), colorElice, glm::vec3(0)), // 0
            VertexFormat(glm::vec3(-x, y, z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 1
            VertexFormat(glm::vec3(x, -y, z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 2
            VertexFormat(glm::vec3(-x, -y, z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 3
            VertexFormat(glm::vec3(x, y, -z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 4
            VertexFormat(glm::vec3(-x, y, -z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 5
            VertexFormat(glm::vec3(x, -y, -z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 6
            VertexFormat(glm::vec3(-x, -y, -z), colorElice, glm::vec3(0.2, 0.8, 0.6)), // 7
        };

        vector<unsigned int> indices =
        {
            0, 1, 2,    // indices for first triangle
            1, 3, 2,    // indices for second triangle
            2, 3, 7,
            2, 7, 6,
            1, 7, 3,
            1, 5, 7,
            6, 7, 4,
            7, 5, 4,
            0, 4, 1,
            1, 4, 5,
            2, 6, 4,
            0, 2, 4,
        };

        meshes["elice"] = new Mesh("generated elice");
        meshes["elice"]->InitFromData(vertices, indices);
    }
    // Teren
    {
        int n = 200;

        vector<VertexFormat> vertices;
        vector<unsigned int> indices;

        // Generare vertec?i
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= n; j++) {
                vertices.push_back(VertexFormat(glm::vec3(i, 0.0, j), glm::vec3(0, 1, 0), glm::vec3(0, 0, 1)));
            }
        }

        // Generare indici
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int start = i * (n + 1) + j;
                indices.push_back(start);
                indices.push_back(start + 1);
                indices.push_back(start + n + 1);

                indices.push_back(start + 1);
                indices.push_back(start + n + 2);
                indices.push_back(start + n + 1);
            }
        }

        meshes["grid"] = new Mesh("generated grid");
        meshes["grid"]->InitFromData(vertices, indices);

    }
    //watchtower
    {
        vector<VertexFormat> watchtowerVertices;
        vector<unsigned int> watchtowerIndices;

        // Dimensiuni
        float towerBaseSize = 1.0f; // Dimensiunea bazei turnului (mai mic? dec�t casa)
        float towerHeight = 5.0f;   // �n?l?imea turnului
        float platformHeight = 0.0f; // �n?l?imea platformei pentru observare

        // Coordonate pentru baza turnului (cub)
        glm::vec3 p1(-towerBaseSize / 2, 0.0f, -towerBaseSize / 2); // St�nga jos spate
        glm::vec3 p2(towerBaseSize / 2, 0.0f, -towerBaseSize / 2);  // Dreapta jos spate
        glm::vec3 p3(towerBaseSize / 2, 0.0f, towerBaseSize / 2);   // Dreapta jos fa??
        glm::vec3 p4(-towerBaseSize / 2, 0.0f, towerBaseSize / 2);  // St�nga jos fa??

        glm::vec3 p5(-towerBaseSize / 2, towerHeight, -towerBaseSize / 2); // St�nga sus spate
        glm::vec3 p6(towerBaseSize / 2, towerHeight, -towerBaseSize / 2);  // Dreapta sus spate
        glm::vec3 p7(towerBaseSize / 2, towerHeight, towerBaseSize / 2);   // Dreapta sus fa??
        glm::vec3 p8(-towerBaseSize / 2, towerHeight, towerBaseSize / 2);  // St�nga sus fa??

        // Adaug? vertec?ii pentru cub (baza turnului)
        watchtowerVertices.push_back(VertexFormat(p1, glm::vec3(0.5, 0.25, 0.1))); // Maro
        watchtowerVertices.push_back(VertexFormat(p2, glm::vec3(0.5, 0.25, 0.1)));
        watchtowerVertices.push_back(VertexFormat(p3, glm::vec3(0.5, 0.25, 0.1)));
        watchtowerVertices.push_back(VertexFormat(p4, glm::vec3(0.5, 0.25, 0.1)));

        watchtowerVertices.push_back(VertexFormat(p5, glm::vec3(0.5, 0.25, 0.1)));
        watchtowerVertices.push_back(VertexFormat(p6, glm::vec3(0.5, 0.25, 0.1)));
        watchtowerVertices.push_back(VertexFormat(p7, glm::vec3(0.5, 0.25, 0.1)));
        watchtowerVertices.push_back(VertexFormat(p8, glm::vec3(0.5, 0.25, 0.1)));

        // Indicii pentru cub
        unsigned int cubeIndices[] = {
            0, 1, 2, 2, 3, 0, // Fa?? de jos
            4, 5, 6, 6, 7, 4, // Fa?? de sus
            0, 1, 5, 5, 4, 0, // Fa?? spate
            1, 2, 6, 6, 5, 1, // Fa?? dreapta
            2, 3, 7, 7, 6, 2, // Fa?? fa??
            3, 0, 4, 4, 7, 3  // Fa?? st�nga
        };

        watchtowerIndices.insert(watchtowerIndices.end(), cubeIndices, cubeIndices + sizeof(cubeIndices) / sizeof(unsigned int));

        // Coordonate pentru platforma turnului
        glm::vec3 platformBase1(-towerBaseSize / 2, towerHeight + platformHeight, -towerBaseSize / 2); // St�nga jos platform?
        glm::vec3 platformBase2(towerBaseSize / 2, towerHeight + platformHeight, -towerBaseSize / 2);  // Dreapta jos platform?
        glm::vec3 platformBase3(towerBaseSize / 2, towerHeight + platformHeight, towerBaseSize / 2);   // Dreapta sus platform?
        glm::vec3 platformBase4(-towerBaseSize / 2, towerHeight + platformHeight, towerBaseSize / 2);  // St�nga sus platform?

        glm::vec3 platformTop(0.0f, towerHeight + platformHeight + 0.5f, 0.0f); // V�rful platformei

        // Adaug? vertec?ii pentru platform?
        watchtowerVertices.push_back(VertexFormat(platformBase1, glm::vec3(0.8, 0.6, 0.4))); // Platform?
        watchtowerVertices.push_back(VertexFormat(platformBase2, glm::vec3(0.8, 0.6, 0.4)));
        watchtowerVertices.push_back(VertexFormat(platformBase3, glm::vec3(0.8, 0.6, 0.4)));
        watchtowerVertices.push_back(VertexFormat(platformBase4, glm::vec3(0.8, 0.6, 0.4)));
        watchtowerVertices.push_back(VertexFormat(platformTop, glm::vec3(0.8, 0.6, 0.4)));

        // Indicii pentru platform?
        unsigned int platformIndices[] = {
            8, 9, 10, 10, 11, 8, // Platform? jos
            8, 9, 12, 9, 10, 12,  // Platform? st�nga/dreapta
            10, 11, 12, 11, 8, 12  // Platform? fa??/spate
        };

        watchtowerIndices.insert(watchtowerIndices.end(), platformIndices, platformIndices + sizeof(platformIndices) / sizeof(unsigned int));

        // Crearea mesh-ului pentru turn
        meshes["watchtower"] = new Mesh("generated watchtower");
        meshes["watchtower"]->InitFromData(watchtowerVertices, watchtowerIndices);
    }

    //copac1
    {
        vector<VertexFormat> treeVertices;
        vector<unsigned int> treeIndices;

        // Dimensiuni
        trunkHeight = 3.0f;  // �n?l?imea trunchiului
        trunkRadius = 0.2f;  // Raza trunchiului
        foliageHeight = 2.0f;  // �n?l?imea coroanei
        foliageBaseRadius = 1.5f;  // Raza de la baz? a coroanei
        float foliageTopRadius = 0.5f;  // Raza v�rfului coroanei

        // Calcul?m �n?l?imea total? a trunchiului, care trebuie s? se prelungeasc? p�n? la dimensiunea coroanei
        float totalHeight = trunkHeight + foliageHeight;

        // Coordonate pentru trunchiul copacului (cilindru)
        glm::vec3 trunkBase(0.0f, 0.0f, 0.0f);  // Baza trunchiului
        glm::vec3 trunkTop(0.0f, trunkHeight, 0.0f);  // V�rful trunchiului

        // Adaug? vertec?ii pentru trunchi (cilindru)
        int trunkSides = 20;  // Num?rul de laturi pentru trunchi
        for (int i = 0; i < trunkSides; i++) {
            float angle = i * 2.0f * glm::pi<float>() / trunkSides;
            float x = trunkRadius * cos(angle);
            float z = trunkRadius * sin(angle);
            glm::vec3 basePoint(x, 0.0f, z);  // Baza trunchiului
            glm::vec3 topPoint(x, trunkHeight, z);  // V�rful trunchiului

            treeVertices.push_back(VertexFormat(basePoint, glm::vec3(0.4, 0.2, 0.1))); // Culoare maro �nchis
            treeVertices.push_back(VertexFormat(topPoint, glm::vec3(0.4, 0.2, 0.1)));  // Culoare maro �nchis
        }

        // Indicii pentru trunchi (cilindru)
        for (int i = 0; i < trunkSides; i++) {
            int next = (i + 1) % trunkSides;
            treeIndices.push_back(i * 2); treeIndices.push_back(i * 2 + 1); treeIndices.push_back(next * 2);  // Trunchi lateral
            treeIndices.push_back(next * 2); treeIndices.push_back(i * 2 + 1); treeIndices.push_back(next * 2 + 1);
        }

        // Coordonate pentru coroana copacului (conuri)
        glm::vec3 coneTop1(0.0f, trunkHeight + foliageHeight, 0.0f);  // V�rful primului con

        // Adaug? vertec?ii pentru coroana copacului
        int foliageSides = 20;  // Num?rul de laturi pentru conuri
        for (int i = 0; i < foliageSides; i++) {
            float angle = i * 2.0f * glm::pi<float>() / foliageSides;

            // Primul con (partea inferioar?)
            glm::vec3 basePoint1(foliageBaseRadius * cos(angle), trunkHeight, foliageBaseRadius * sin(angle));
            treeVertices.push_back(VertexFormat(basePoint1, glm::vec3(0.1, 0.3, 0.1))); // Verde �nchis
            treeVertices.push_back(VertexFormat(coneTop1, glm::vec3(0.1, 0.3, 0.1))); // Verde �nchis
        }

        // Indicii pentru coroan? (conuri)
        for (int i = 0; i < foliageSides; i++) {
            int next = (i + 1) % foliageSides;
            // Primul con
            treeIndices.push_back(i * 2 + trunkSides * 2); treeIndices.push_back(i * 2 + trunkSides * 2 + 1); treeIndices.push_back(next * 2 + trunkSides * 2);
            treeIndices.push_back(next * 2 + trunkSides * 2); treeIndices.push_back(i * 2 + trunkSides * 2 + 1); treeIndices.push_back(next * 2 + trunkSides * 2 + 1);
        }

        // Crearea mesh-ului pentru copac
        meshes["tree"] = new Mesh("generated tree");
        meshes["tree"]->InitFromData(treeVertices, treeIndices);
    }
    // Checkpoint
    {
        vector<VertexFormat> checkpointVertices;
        vector<unsigned int> checkpointIndices;

        // Circle Dimensions
        float radius = 1.0f;        // Radius of the vertical circle
        float thickness = 0.3f;     // Thickness of the circle (small depth)
        float glowRadius = radius + 0.1f; // Slightly larger radius for the glow effect
        float glowThickness = 0.05f;      // Smaller thickness for the glow
        int segments = 36;          // Number of segments for the circle

        glm::vec3 frontColor = glm::vec3(0.0f, 1.0f, 0.0f); // Green for the front face
        glm::vec3 backColor = glm::vec3(1.0f, 1.0f, 0.0f);  // Yellow for the back face
        glm::vec3 glowColor = glm::vec3(1.0f, 1.0f, 0.5f);  // Light yellow for the glow
        glm::vec3 stickColor = glm::vec3(0.8f, 0.8f, 0.8f); // Light gray for the stick

        // Stick Dimensions
        float stickLength = 1.5f;   // Length of the stick
        float stickThickness = 0.1f; // Thickness of the stick

        // Adjust position so the circle is at the very top of the stick
        float circleBaseY = stickLength + radius;  // Top of stick aligns with bottom of circle

        // Generate vertices for the vertical circle (Front and Back)
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float x = radius * cos(angle);
            float y = radius * sin(angle) + circleBaseY;

            // Front side of the circle (green color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, thickness / 2.0f), frontColor));

            // Back side of the circle (yellow color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, -thickness / 2.0f), backColor));
        }

        // Add indices for the circle (Front and Back faces)
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % (segments + 1);

            // Front face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2 + 1);

            // Back face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2);
        }

        // Generate vertices for the glow ring
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float x = glowRadius * cos(angle);
            float y = glowRadius * sin(angle) + circleBaseY; // Place the glow ring slightly above the circle

            // Front side of the glow (light yellow)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, glowThickness / 2.0f), glowColor));

            // Back side of the glow (light yellow)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, -glowThickness / 2.0f), glowColor));
        }

        // Add indices for the glow ring (similar to the circle's indices)
        int glowBaseIndex = (segments + 1) * 2;
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % (segments + 1);

            // Front face of the glow (as a quad split into two triangles)
            checkpointIndices.push_back(glowBaseIndex + i * 2);
            checkpointIndices.push_back(glowBaseIndex + next * 2);
            checkpointIndices.push_back(glowBaseIndex + next * 2 + 1);
            checkpointIndices.push_back(glowBaseIndex + i * 2);
            checkpointIndices.push_back(glowBaseIndex + next * 2 + 1);
            checkpointIndices.push_back(glowBaseIndex + i * 2 + 1);

            // Back face of the glow (as a quad split into two triangles)
            checkpointIndices.push_back(glowBaseIndex + i * 2 + 1);
            checkpointIndices.push_back(glowBaseIndex + next * 2 + 1);
            checkpointIndices.push_back(glowBaseIndex + next * 2);
            checkpointIndices.push_back(glowBaseIndex + i * 2 + 1);
            checkpointIndices.push_back(glowBaseIndex + next * 2);
            checkpointIndices.push_back(glowBaseIndex + i * 2);
        }

        // Generate vertices for the stick
        glm::vec3 bottom = glm::vec3(0.0f, 0.0f, -stickThickness / 2.0f);
        glm::vec3 top = glm::vec3(0.0f, stickLength, -stickThickness / 2.0f);

        // Add stick vertices (front and back faces)
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, -stickThickness / 2.0f), stickColor));

        // Add indices for the stick
        int stickBaseIndex = (segments + 1) * 2 + (segments + 1) * 2;
        unsigned int stickIndices[] = {
            stickBaseIndex, stickBaseIndex + 1, stickBaseIndex + 2, stickBaseIndex, stickBaseIndex + 2, stickBaseIndex + 3, // Front face
            stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 4, stickBaseIndex + 6, stickBaseIndex + 7, // Back face
            stickBaseIndex, stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex, stickBaseIndex + 5, stickBaseIndex + 1, // Side faces
            stickBaseIndex + 1, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 1, stickBaseIndex + 6, stickBaseIndex + 2,
            stickBaseIndex + 2, stickBaseIndex + 6, stickBaseIndex + 7, stickBaseIndex + 2, stickBaseIndex + 7, stickBaseIndex + 3,
            stickBaseIndex + 3, stickBaseIndex + 7, stickBaseIndex + 4, stickBaseIndex + 3, stickBaseIndex + 4, stickBaseIndex
        };
        checkpointIndices.insert(checkpointIndices.end(), std::begin(stickIndices), std::end(stickIndices));

        // Create the mesh for the lollipop checkpoint with halo glow
        meshes["checkpoint"] = new Mesh("generated lollipop checkpoint with halo glow");
        meshes["checkpoint"]->InitFromData(checkpointVertices, checkpointIndices);
    }

    //next_checkpoint
    {
        vector<VertexFormat> checkpointVertices;
        vector<unsigned int> checkpointIndices;

        // Circle Dimensions
        float radius = 1.0f;        // Radius of the vertical circle
        float thickness = 0.3f;     // Thickness of the circle (small depth)
        float glowRadius = radius + 0.1f; // Slightly larger radius for the glow effect
        float glowThickness = 0.05f;      // Smaller thickness for the glow
        int segments = 36;          // Number of segments for the circle

        glm::vec3 frontColor = glm::vec3(0.32f, 0.32f, 0.32f); // Bright blue for the front face
        glm::vec3 backColor = glm::vec3(0.5f, 0.5f, 0.5f);  // Bright pink for the back face
        glm::vec3 glowColor = glm::vec3(1.0f, 0.5f, 1.0f);  // Light pink for the glow
        glm::vec3 stickColor = glm::vec3(0.8f, 0.8f, 0.8f); // Light gray for the stick (unchanged)


        // Stick Dimensions
        float stickLength = 1.5f;   // Length of the stick
        float stickThickness = 0.1f; // Thickness of the stick

        // Adjust position so the circle is at the very top of the stick
        float circleBaseY = stickLength + radius;  // Top of stick aligns with bottom of circle

        // Generate vertices for the vertical circle (Front and Back)
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float x = radius * cos(angle);
            float y = radius * sin(angle) + circleBaseY;

            // Front side of the circle (green color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, thickness / 2.0f), frontColor));

            // Back side of the circle (yellow color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, -thickness / 2.0f), backColor));
        }

        // Add indices for the circle (Front and Back faces)
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % (segments + 1);

            // Front face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2 + 1);

            // Back face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2);
        }

        // Generate vertices for the stick
        glm::vec3 bottom = glm::vec3(0.0f, 0.0f, -stickThickness / 2.0f);
        glm::vec3 top = glm::vec3(0.0f, stickLength, -stickThickness / 2.0f);

        // Add stick vertices (front and back faces)
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, -stickThickness / 2.0f), stickColor));

        // Add indices for the stick
        int stickBaseIndex = (segments + 1) * 2;
        unsigned int stickIndices[] = {
            stickBaseIndex, stickBaseIndex + 1, stickBaseIndex + 2, stickBaseIndex, stickBaseIndex + 2, stickBaseIndex + 3, // Front face
            stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 4, stickBaseIndex + 6, stickBaseIndex + 7, // Back face
            stickBaseIndex, stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex, stickBaseIndex + 5, stickBaseIndex + 1, // Side faces
            stickBaseIndex + 1, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 1, stickBaseIndex + 6, stickBaseIndex + 2,
            stickBaseIndex + 2, stickBaseIndex + 6, stickBaseIndex + 7, stickBaseIndex + 2, stickBaseIndex + 7, stickBaseIndex + 3,
            stickBaseIndex + 3, stickBaseIndex + 7, stickBaseIndex + 4, stickBaseIndex + 3, stickBaseIndex + 4, stickBaseIndex
        };
        checkpointIndices.insert(checkpointIndices.end(), std::begin(stickIndices), std::end(stickIndices));

        // Create the mesh for the lollipop checkpoint
        meshes["checkpointDeactivated"] = new Mesh("generated lollipop checkpoint");
        meshes["checkpointDeactivated"]->InitFromData(checkpointVertices, checkpointIndices);
    }
    //deactivated_checkpoint
    {
        vector<VertexFormat> checkpointVertices;
        vector<unsigned int> checkpointIndices;

        // Circle Dimensions
        float radius = 1.0f;        // Radius of the vertical circle
        float thickness = 0.3f;     // Thickness of the circle (small depth)
        float glowRadius = radius + 0.1f; // Slightly larger radius for the glow effect
        float glowThickness = 0.05f;      // Smaller thickness for the glow
        int segments = 36;          // Number of segments for the circle

        glm::vec3 frontColor = glm::vec3(0.4392f, 0.576f, 0.858f); // Bright blue for the front face
        glm::vec3 backColor = glm::vec3(0.184f, 0.18f, 0.309f);  // Bright pink for the back face
        glm::vec3 glowColor = glm::vec3(1.0f, 0.5f, 1.0f);  // Light pink for the glow
        glm::vec3 stickColor = glm::vec3(0.6f, 0.6f, 0.6f); // Light gray for the stick (unchanged)


        // Stick Dimensions
        float stickLength = 1.5f;   // Length of the stick
        float stickThickness = 0.1f; // Thickness of the stick

        // Adjust position so the circle is at the very top of the stick
        float circleBaseY = stickLength + radius;  // Top of stick aligns with bottom of circle

        // Generate vertices for the vertical circle (Front and Back)
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float x = radius * cos(angle);
            float y = radius * sin(angle) + circleBaseY;

            // Front side of the circle (green color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, thickness / 2.0f), frontColor));

            // Back side of the circle (yellow color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, -thickness / 2.0f), backColor));
        }

        // Add indices for the circle (Front and Back faces)
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % (segments + 1);

            // Front face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2 + 1);

            // Back face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2);
        }

        // Generate vertices for the stick
        glm::vec3 bottom = glm::vec3(0.0f, 0.0f, -stickThickness / 2.0f);
        glm::vec3 top = glm::vec3(0.0f, stickLength, -stickThickness / 2.0f);

        // Add stick vertices (front and back faces)
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, -stickThickness / 2.0f), stickColor));

        // Add indices for the stick
        int stickBaseIndex = (segments + 1) * 2;
        unsigned int stickIndices[] = {
            stickBaseIndex, stickBaseIndex + 1, stickBaseIndex + 2, stickBaseIndex, stickBaseIndex + 2, stickBaseIndex + 3, // Front face
            stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 4, stickBaseIndex + 6, stickBaseIndex + 7, // Back face
            stickBaseIndex, stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex, stickBaseIndex + 5, stickBaseIndex + 1, // Side faces
            stickBaseIndex + 1, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 1, stickBaseIndex + 6, stickBaseIndex + 2,
            stickBaseIndex + 2, stickBaseIndex + 6, stickBaseIndex + 7, stickBaseIndex + 2, stickBaseIndex + 7, stickBaseIndex + 3,
            stickBaseIndex + 3, stickBaseIndex + 7, stickBaseIndex + 4, stickBaseIndex + 3, stickBaseIndex + 4, stickBaseIndex
        };
        checkpointIndices.insert(checkpointIndices.end(), std::begin(stickIndices), std::end(stickIndices));

        // Create the mesh for the lollipop checkpoint
        meshes["checkpointNext"] = new Mesh("generated lollipop checkpoint");
        meshes["checkpointNext"]->InitFromData(checkpointVertices, checkpointIndices);
    }


    //completed_checkpoint
    {
        vector<VertexFormat> checkpointVertices;
        vector<unsigned int> checkpointIndices;

        // Circle Dimensions
        float radius = 0.5f;        // Radius of the vertical circle
        float thickness = 0.3f;     // Thickness of the circle (small depth)
        float glowRadius = radius + 0.1f; // Slightly larger radius for the glow effect
        float glowThickness = 0.05f;      // Smaller thickness for the glow
        int segments = 36;          // Number of segments for the circle

        glm::vec3 frontColor = glm::vec3(1.0f, 1.0f, 0.8f); // Bright blue for the front face
        glm::vec3 backColor = glm::vec3(1.0f, 1.0f, 0.8f);  // Bright pink for the back face
        glm::vec3 glowColor = glm::vec3(1.0f, 0.5f, 1.0f);  // Light pink for the glow
        glm::vec3 stickColor = glm::vec3(1.0f, 1.0f, 0.8f); // Light gray for the stick (unchanged)


        // Stick Dimensions
        float stickLength = 1.5f;   // Length of the stick
        float stickThickness = 0.1f; // Thickness of the stick

        // Adjust position so the circle is at the very top of the stick
        float circleBaseY = stickLength + radius;  // Top of stick aligns with bottom of circle

        // Generate vertices for the vertical circle (Front and Back)
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float x = radius * cos(angle);
            float y = radius * sin(angle) + circleBaseY;

            // Front side of the circle (green color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, thickness / 2.0f), frontColor));

            // Back side of the circle (yellow color)
            checkpointVertices.push_back(VertexFormat(glm::vec3(x, y, -thickness / 2.0f), backColor));
        }

        // Add indices for the circle (Front and Back faces)
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % (segments + 1);

            // Front face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(i * 2 + 1);

            // Back face (as a quad split into two triangles)
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2 + 1);
            checkpointIndices.push_back(next * 2);
            checkpointIndices.push_back(i * 2);
        }

        // Generate vertices for the stick
        glm::vec3 bottom = glm::vec3(0.0f, 0.0f, -stickThickness / 2.0f);
        glm::vec3 top = glm::vec3(0.0f, stickLength, -stickThickness / 2.0f);

        // Add stick vertices (front and back faces)
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, bottom.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(stickThickness, top.y, -stickThickness / 2.0f), stickColor));
        checkpointVertices.push_back(VertexFormat(glm::vec3(-stickThickness, top.y, -stickThickness / 2.0f), stickColor));

        // Add indices for the stick
        int stickBaseIndex = (segments + 1) * 2;
        unsigned int stickIndices[] = {
            stickBaseIndex, stickBaseIndex + 1, stickBaseIndex + 2, stickBaseIndex, stickBaseIndex + 2, stickBaseIndex + 3, // Front face
            stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 4, stickBaseIndex + 6, stickBaseIndex + 7, // Back face
            stickBaseIndex, stickBaseIndex + 4, stickBaseIndex + 5, stickBaseIndex, stickBaseIndex + 5, stickBaseIndex + 1, // Side faces
            stickBaseIndex + 1, stickBaseIndex + 5, stickBaseIndex + 6, stickBaseIndex + 1, stickBaseIndex + 6, stickBaseIndex + 2,
            stickBaseIndex + 2, stickBaseIndex + 6, stickBaseIndex + 7, stickBaseIndex + 2, stickBaseIndex + 7, stickBaseIndex + 3,
            stickBaseIndex + 3, stickBaseIndex + 7, stickBaseIndex + 4, stickBaseIndex + 3, stickBaseIndex + 4, stickBaseIndex
        };
        checkpointIndices.insert(checkpointIndices.end(), std::begin(stickIndices), std::end(stickIndices));

        // Create the mesh for the lollipop checkpoint
        meshes["checkpointCompleted"] = new Mesh("generated lollipop checkpoint");
        meshes["checkpointCompleted"]->InitFromData(checkpointVertices, checkpointIndices);
    }
    // Arrow
    {
        vector<VertexFormat> arrowVertices;
        vector<unsigned int> arrowIndices;

        // Arrow Dimensions
        float shaftLength = 0.3f;      // Length of the arrow's shaft
        float shaftRadius = 0.05f;      // Radius of the shaft
        float headLength = 0.5f;       // Length of the arrowhead
        float headRadius = 0.03f;       // Radius of the arrowhead
        int segments = 36;             // Number of segments for the circle (for the shaft and arrowhead base)

        glm::vec3 shaftColor = glm::vec3(0.8f, 0.8f, 0.8f);   // Light gray for the shaft
        glm::vec3 headColor = glm::vec3(1.0f, 0.0f, 0.0f);    // Red for the arrowhead

        // Generate vertices for the shaft (a simple cylinder)
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float z = shaftRadius * cos(angle);   // Change x to z for horizontal
            float y = shaftRadius * sin(angle);

            // Bottom part of the shaft (positioned at the origin)
            arrowVertices.push_back(VertexFormat(glm::vec3(0.0f, y, z), shaftColor));

            // Top part of the shaft (positioned along X axis, extending from the origin)
            arrowVertices.push_back(VertexFormat(glm::vec3(shaftLength, y, z), shaftColor));
        }

        // Add indices for the shaft (side faces)
        int baseIndex = 0;
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % segments;

            // Side faces of the shaft (as a quad split into two triangles)
            arrowIndices.push_back(baseIndex + i * 2);
            arrowIndices.push_back(baseIndex + next * 2);
            arrowIndices.push_back(baseIndex + next * 2 + 1);
            arrowIndices.push_back(baseIndex + i * 2);
            arrowIndices.push_back(baseIndex + next * 2 + 1);
            arrowIndices.push_back(baseIndex + i * 2 + 1);
        }

        // Generate vertices for the arrowhead (a cone-like shape)
        glm::vec3 tip = glm::vec3(shaftLength + headLength, 0.0f, 0.0f);  // Tip of the arrowhead (moved to the right along X axis)
        for (int i = 0; i <= segments; ++i) {
            float angle = i * 2.0f * glm::pi<float>() / segments;
            float z = headRadius * cos(angle);    // Change x to z for horizontal
            float y = headRadius * sin(angle);

            // Base of the arrowhead (at the top of the shaft)
            arrowVertices.push_back(VertexFormat(glm::vec3(shaftLength, y, z), headColor));

            // Tip of the arrowhead (the point of the arrow)
            arrowVertices.push_back(VertexFormat(tip, headColor));
        }

        // Add indices for the arrowhead (side faces)
        int headBaseIndex = arrowVertices.size() - (segments + 1) * 2;
        for (int i = 0; i < segments; ++i) {
            int next = (i + 1) % segments;

            // Side faces of the arrowhead (as a triangle fan)
            arrowIndices.push_back(headBaseIndex + i * 2);
            arrowIndices.push_back(headBaseIndex + next * 2);
            arrowIndices.push_back(headBaseIndex + i * 2 + 1);
        }

        // Create the mesh for the arrow
        meshes["arrow"] = new Mesh("generated arrow");
        meshes["arrow"]->InitFromData(arrowVertices, arrowIndices);
    }




    // Lab Shader
    {
        Shader* shader = new Shader("LabShader");
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema2", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema2", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
        shader->CreateAndLink();
        shaders[shader->GetName()] = shader;
    }

    {
        Mesh* mesh = new Mesh("box");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    {
        Mesh* mesh = new Mesh("sphere");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "sphere.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }
}


void Tema2::FrameStart()
{

    projectionMatrix = orthoProjection
        ? glm::ortho(-projectionWidth / 2, projectionWidth / 2, -projectionHeight / 2, projectionHeight / 2, .01f, 200.0f)
        : glm::perspective(RADIANS(projectionFov), window->props.aspectRatio, 0.01f, 200.0f);
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}




void Tema2::Update(float deltaTimeSeconds)
{
	///////////////////////////////////////////////TEREN///////////////////////////////////////////////
	
		glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(-50, 0, -50));
		RenderMesh(meshes["grid"], shaders["LabShader"], modelMatrix);

	///////////////////////////////////////////////CASA/////////////////////////////////////////////////
		for (int i = 0; i < nrHouses; i++)
		{
			glm::vec3 position = housePositions[i];
			//printf("House position: %f %f %f\n", position.x, position.y, position.z);
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::translate(modelMatrix, position);
			RenderMesh(meshes["watchtower"], shaders["VertexColor"], modelMatrix);

		}
      
    ////////////////////////////////////////////////COPAC///////////////////////////////////////////////
		for (int i = 0; i < nrTrees; i++)
        {
            glm::mat4 modelMatrix = glm::mat4(1);
            modelMatrix = glm::translate(modelMatrix, treePositions[i]);
            RenderMesh(meshes["tree"], shaders["VertexColor"], modelMatrix);
        }

		////////////////////////////////////////////////CHECKPOINT///////////////////////////////////////////////
   
        if (checkpointStates[currentCheckpoint] == DEACTIVATED) {
			checkpointStates[currentCheckpoint] = NOT_ENTERED;
           
        }

        for (int i = 0; i < nrCheckpoints; i++)
        {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glm::mat4 modelMatrix = glm::mat4(1);
            modelMatrix = glm::translate(modelMatrix, nextCheckpoints[i]);
            // modelMatrix = glm::translate(modelMatrix, glm::vec3(0,0,0));
            if (checkpointStates[i] == COMPLETED) {
				RenderMesh(meshes["checkpointCompleted"], shaders["VertexColor"], modelMatrix);
            }
			else if (i != currentCheckpoint && i != currentCheckpoint+1)
              RenderMesh(meshes["checkpointDeactivated"], shaders["VertexColor"], modelMatrix);
			else if (i == currentCheckpoint)
			{
				RenderMesh(meshes["checkpoint"], shaders["VertexColor"], modelMatrix);
			}
			else if (i == currentCheckpoint + 1)
			{
				RenderMesh(meshes["checkpointNext"], shaders["VertexColor"], modelMatrix);
			}
        }
      

	////////////////////////////////////////////////DRONA///////////////////////////////////////////////

    // Now you have the local axes (forward, right, up) for the drone

    // Position and rotation of the drone
        {
            droneModelMatrix = glm::mat4(1);
            droneModelMatrix = glm::translate(droneModelMatrix, glm::vec3(translateX, 1 + translateZ, translateY));
            droneModelMatrix = glm::rotate(droneModelMatrix, RADIANS(45.0f + rotationAngleDrona), glm::vec3(0, 1, 0));


            // check if collision with ground is made:
			if (CheckGroundCollision(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])) || CheckCollisionWithObstacles(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])))
            {
				// If the drone has collided with the ground, stop the drone from falling
                // move drone behind
                RenderMesh(meshes["Drona"], shaders["VertexColor"], oldModelMatrix);
			}
            else {
                RenderMesh(meshes["Drona"], shaders["VertexColor"], droneModelMatrix);
                oldModelMatrix = droneModelMatrix;
            }
	
        }
    // Propellers (adjust their position based on local axes)
    for (int i = 0; i < 4; ++i) {
        propellerModelMatrices[i] = glm::mat4(1);
        propellerModelMatrices[i] = glm::translate(propellerModelMatrices[i], glm::vec3(translateX, 1 + translateZ, translateY)); // Global position
        
        // Calculate propeller offset in local space using the local right and forward axes
        glm::vec3 rotatedOffset = RotateAroundYAxis(propellerOffsets[i], RADIANS(-rotationAngleDrona)); // Rotate propeller position based on drone's angle
        
        // Apply the rotated offset to move the propeller relative to the drone
        propellerModelMatrices[i] = glm::translate(propellerModelMatrices[i], rotatedOffset);

        // Rotate propeller along its own axis
        propellerModelMatrices[i] = glm::rotate(propellerModelMatrices[i], RADIANS(rotationAngleElice), glm::vec3(0, 1, 0)); // Spin propeller
        if (CheckGroundCollision(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])) || CheckCollisionWithObstacles(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])))
        {
			propellerModelMatrices[i] = oldPropellerModelMatrices[i];
        }
        RenderMesh(meshes["elice"], shaders["VertexColor"], propellerModelMatrices[i]);
		oldPropellerModelMatrices[i] = propellerModelMatrices[i];

       
    }


    ///////////////////////////////////////////////////////////////ARROW//////////////////////////////////////////////////////////////////
	{
		/*arrowMatrix = glm::mat4(1);
		arrowMatrix = glm::translate(modelMatrix, glm::vec3(translateX, 1f + translateZ, translateY));
		arrowMatrix = glm::rotate(modelMatrix, RADIANS(45.0f + rotationAngleDrona), glm::vec3(0, 1, 0));
        if (CheckGroundCollision(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])) || CheckCollisionWithObstacles(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])))
        {
			arrowMatrix = oldArrowMatrix;
        }
		RenderMesh(meshes["arrow"], shaders["VertexColor"], modelMatrix);
		oldArrowMatrix = arrowMatrix;*/
		arrowMatrix = glm::mat4(1);
     
		// rotate it
        arrowMatrix = glm::translate(arrowMatrix, glm::vec3(translateX, 1.0f + translateZ, translateY));

        // Calculate propeller offset in local space using the local right and forward axes
        glm::vec3 rotatedOffset = RotateAroundYAxis(glm::vec3 (0,0.8f,-1), RADIANS(-rotationAngleDrona)); // Rotate propeller position based on drone's angle

        // Apply the rotated offset to move the propeller relative to the drone
       arrowMatrix = glm::translate(arrowMatrix, rotatedOffset);



		glm::vec3 checkpointPosition = nextCheckpoints[currentCheckpoint];
		// get arrow vector
		glm::vec3 arrowVector = glm::vec3 (arrowMatrix[3][0], 0, arrowMatrix[3][2]);
		glm::vec3 checkpointVector = glm::vec3(checkpointPosition.x, 0, checkpointPosition.z) ;
        // Compute the direction vector from the arrow to the checkpoint
        glm::vec3 direction = checkpointVector - arrowVector;
        // get length
		float length = glm::length(direction);

	//	float angle = asin(checkpointPosition.z / length);
        float angle = atan2(direction.z, direction.x); // Correct angle around Y-axis
		//angle += RADIANS(rotationAngleDrona);

		// the new angle is  the rotated angle + the angle between the arrow and the checkpoint
		//angle += rotationAngleDrona;
        
        // Apply the rotation to the arrow
       arrowMatrix = glm::rotate(arrowMatrix, -angle , glm::vec3(0, 1, 0));  //
		//arrowMatrix = glm::rotate(arrowMatrix, RADIANS(180.0f), glm::vec3(1, 0, 0));

        if (CheckGroundCollision(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])) || CheckCollisionWithObstacles(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])))
        {
			arrowMatrix = oldArrowMatrix;
		}
        
		RenderMesh(meshes["arrow"], shaders["VertexColor"], arrowMatrix);
		oldArrowMatrix = arrowMatrix;
	}


    


   /* {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 1, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(45.0f), glm::vec3(0, 1, 0));

        RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
    }

    {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(2, 0.5f, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(60.0f), glm::vec3(1, 0, 0));
        RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
    }*/


	////////////////////////////////////////////////CAMERA///////////////////////////////////////////////

    // Calculate the drone's forward direction
     glm::vec3 forward2 = glm::normalize(glm::vec3(
         -sin(RADIANS(  rotationAngleDrona)), // X component
         0,                                       // Y remains constant
         -cos(RADIANS( rotationAngleDrona)) // Z component
     ));

     // Offset to place the camera behind the drone
     float offsetDistance = 1.5f; // Distance behind the drone
	 float offsetHeight = 0.3f; // Height above the drone
     glm::vec3 behindOffset = -forward2 * offsetDistance;
	 // Move backwards
	 behindOffset.y = offsetHeight;

     if (CheckGroundCollision(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])) || CheckCollisionWithObstacles(glm::vec3(droneModelMatrix[3][0], droneModelMatrix[3][1], droneModelMatrix[3][2])))
     {
         translateX = oldCameraX;
         translateY = oldCameraY;
         translateZ = oldCameraZ;

     }

     // Camera position (slightly behind the drone's position, with an upward offset)
     glm::vec3 cameraPosition = glm::vec3(translateX, 1.5f + translateZ, translateY) + behindOffset;

     // Camera target (looking forward from the drone)
     glm::vec3 targetPosition = glm::vec3(translateX, 1.5f + translateZ, translateY) + forward2;

	
    


     // Update camera's view matrix
     camera->Set(cameraPosition, targetPosition, glm::vec3(0, 1, 0)); // Set new camera position, target, and up vector
     oldCameraX = translateX;
     oldCameraY = translateY;
     oldCameraZ = translateZ;
  
}


void Tema2::FrameEnd()
{
    DrawCoordinateSystem(camera->GetViewMatrix(), projectionMatrix);
}


void Tema2::RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix)
{
    if (!mesh || !shader || !shader->program)
        return;

    // Render an object using the specified shader and the specified position
    shader->Use();
    glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
    glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
    glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    mesh->Render();
    //glActiveTexture(GL_TEXTURE0);
    //glUniform1i(glGetUniformLocation(shader->program, "u_texture_0"), 0);
    //glUniform1i(glGetUniformLocation(shader->program, "useTexture"), 1);
    //glUniform3fv(glGetUniformLocation(shader->program, "overrideColor"), 1, glm::value_ptr(glm::vec3(2, 2, 2)));
    //mesh->Render();
    
}


/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Tema2::OnInputUpdate(float deltaTime, int mods)
{
    // move the camera only if MOUSE_RIGHT button is pressed
    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float cameraSpeed = 2.0f;

        if (window->KeyHold(GLFW_KEY_W)) {
            camera->TranslateForward(deltaTime * cameraSpeed);
        }

        if (window->KeyHold(GLFW_KEY_A)) {
            camera->TranslateRight(-deltaTime * cameraSpeed);

        }

        if (window->KeyHold(GLFW_KEY_S)) {
            camera->TranslateForward(-deltaTime * cameraSpeed);

        }

        if (window->KeyHold(GLFW_KEY_D)) {
            camera->TranslateRight(deltaTime * cameraSpeed);

        }

        if (window->KeyHold(GLFW_KEY_Q)) {
            camera->TranslateUpward(-deltaTime * cameraSpeed);
        }

        if (window->KeyHold(GLFW_KEY_E)) {
            camera->TranslateUpward(deltaTime * cameraSpeed);
        }
    }

    if (window->KeyHold(GLFW_KEY_1)) {
        projectionFov -= deltaTime * 10;
    }
    if (window->KeyHold(GLFW_KEY_2)) {
        projectionFov += deltaTime * 10;
    }

    if (window->KeyHold(GLFW_KEY_3)) {
        projectionWidth += 5 * deltaTime;
    }
    if (window->KeyHold(GLFW_KEY_4)) {
        projectionWidth -= 5 * deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_5)) {
        projectionHeight += 5 * deltaTime;
    }
    if (window->KeyHold(GLFW_KEY_6)) {
        projectionHeight -= 5 * deltaTime;
    }

    // TODO(student): Change projection parameters. Declare any extra
    // variables you might need in the class header. Inspect this file
    // for any hardcoded projection arguments (can you find any?) and
    // replace them with those extra variables.
    float rotationSpeed = 800; // Degrees per second
	float rotationLowSpeed = 200;
    rotationAngleElice += rotationSpeed * deltaTime; // deltaTime should be the time elapsed between frames
    if (rotationAngleElice >= 360.0f) {
        rotationAngleElice -= 360.0f; // Keep the angle within 0 to 360 degrees
    }

    float movementSpeed = 4.0f; // Units per second
  

    // Movement control: Update translation based on local axes
    if (window->KeyHold(GLFW_KEY_UP)) {
        // Move the drone forward along the forward vector
        translateX += sin(RADIANS( rotationAngleDrona)) * movementSpeed * deltaTime;
        translateY += cos(RADIANS( rotationAngleDrona)) * movementSpeed * deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_DOWN)) {
        // Move the drone backward along the forward vector (opposite direction)
        translateX -= sin(RADIANS( rotationAngleDrona)) * movementSpeed * deltaTime;
        translateY -= cos(RADIANS( rotationAngleDrona)) * movementSpeed * deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_LEFT)) {
        // Move the drone left along the right vector
        translateX += sin(RADIANS(90.0f + rotationAngleDrona)) * movementSpeed * deltaTime;
        translateY += cos(RADIANS(90.0f + rotationAngleDrona)) * movementSpeed * deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_RIGHT)) {
        // Move the drone right along the right vector
        translateX -= sin(RADIANS(90.0f + rotationAngleDrona)) * movementSpeed * deltaTime;
        translateY -= cos(RADIANS(90.0f + rotationAngleDrona)) * movementSpeed * deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_U)) {
        // Move the drone upward along the up vector
        translateZ += movementSpeed * deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_H)) {
        // Move the drone downward along the up vector (opposite direction)
    
        translateZ -= movementSpeed * deltaTime;
    }

    // Rotation control: Update rotation angle around the Y-axis (around the "up" vector)
    if (window->KeyHold(GLFW_KEY_J)) {
        rotationAngleDrona += rotationLowSpeed * deltaTime;
        if (rotationAngleDrona >= 360.0f) {
            rotationAngleDrona -= 360.0f;
        }
    }

    if (window->KeyHold(GLFW_KEY_K)) {
        rotationAngleDrona -= rotationLowSpeed * deltaTime;
        if (rotationAngleDrona < 0.0f) {
            rotationAngleDrona += 360.0f;
        }
    }


}


void Tema2::OnKeyPress(int key, int mods)
{
    // Add key press event
    if (key == GLFW_KEY_T)
    {
        renderCameraTarget = !renderCameraTarget;
    }
    // TODO(student): Switch projections
    if (key == GLFW_KEY_O) orthoProjection = true;
    else if (key == GLFW_KEY_P) orthoProjection = false;


    //////////////////////////////////
   
}


void Tema2::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event

    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float sensivityOX = 0.001f;
        float sensivityOY = 0.001f;

        if (window->GetSpecialKeyState() == 0) {
            renderCameraTarget = false;
            // TODO(student): Rotate the camera in first-person mode around
            // OX and OY using `deltaX` and `deltaY`. Use the sensitivity
            // variables for setting up the rotation speed.
            camera->RotateFirstPerson_OX(-deltaY * sensivityOX);
            camera->RotateFirstPerson_OY(-deltaX * sensivityOY);
        }

        if (window->GetSpecialKeyState() & GLFW_MOD_CONTROL) {
            renderCameraTarget = true;
            // TODO(student): Rotate the camera in third-person mode around
            // OX and OY using `deltaX` and `deltaY`. Use the sensitivity
            // variables for setting up the rotation speed.
            camera->RotateThirdPerson_OX(-deltaY * sensivityOX);
            camera->RotateThirdPerson_OY(-deltaX * sensivityOY);
        }
    }
}


void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
}


void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema2::OnWindowResize(int width, int height)
{
}